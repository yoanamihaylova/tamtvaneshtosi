﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using RentACar.Controllers.Models;
using RentACar.Database;
using RentACar.Database.Models;
using RentACar.Models;

namespace RentACar.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        public DatabaseController dc;
        public static User loggedUser = null;
        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
            this.dc = new DatabaseController(new RentACar.Database.RentACar());
        }

        public IActionResult Index()
        {
            if (loggedUser == null) return RedirectToAction(nameof(Login));
            else return View();
        }
        public IActionResult Login(User user)
        {
            if (dc.getAllUsers().Any(u => u.password == user.password && u.username == user.username))
            {
                loggedUser = user;
                return RedirectToAction(nameof(Index));
            }
           // return Login();
             return View();
        }
        public IActionResult Register(UserVM user)
        {

            if (ModelState.IsValid == true)
            {
                user.id = default;
                if (dc.getAllUsers().Count > 0) user.role = "Client";
                else user.role = "Administrator";
                User nov = new User(user);
                
                dc.addUser(nov);
                loggedUser = nov;
                return RedirectToAction(nameof(Index));
            }
            // return RedirectToAction(nameof (Loggin));
            return View();
        }
        public IActionResult Privacy()
        {
            return View();
        }
          public IActionResult Cars(CarVM car)
        {

            car.cars = dc.getAllCars();
            return View(car);
        }

        public IActionResult CreateCar(CarVM car)
        {

            if (ModelState.IsValid == true)
            {
                car.id = default;
                Car nov = new Car(car);
                dc.addCar(nov);
                return RedirectToAction(nameof(Cars));
            }
            return View();

        }
        public IActionResult DeleteCar(int id)
        {

            if (ModelState.IsValid == true)
            {
                dc.deleteCar(id);
                return RedirectToAction(nameof(Cars));
            }
            return View();

        }
        public IActionResult Users(UserVM user)
        {

            user.users = dc.getAllUsers();
            return View(user);
        }
        public IActionResult CreateUser(UserVM user)
        {

            if (ModelState.IsValid == true)
            {
                user.id = default;
                User nov = new User(user);
                dc.addUser(nov);
                return RedirectToAction(nameof(Users));
            }
            return View();

        }

        public IActionResult Rents(RentVM rent)
        {

            rent.rents = dc.getAllRents();
            return View(rent);
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }


    }
}
