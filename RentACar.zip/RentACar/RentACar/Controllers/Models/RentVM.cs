﻿using RentACar.Database.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace RentACar.Controllers.Models
{
    public class RentVM
    {
        public List<Rent> rents { get; set; }
     
        public int id { get; set; }
        public DateTime startDate { get; set; }
         
        [Required]
        public DateTime endDate { get; set; }
        public virtual Car car { get; set; }   

      
        public virtual User user { get; set; }
        public decimal finalPrice { get; set; }
        public string status { get; set; }



    }
}
