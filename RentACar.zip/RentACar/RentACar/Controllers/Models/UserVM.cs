﻿using RentACar.Database.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace RentACar.Controllers.Models
{
    public class UserVM
    {
        public List<User> users { get; set; }
        public int id { get; set; }
        [Required]
        [MaxLength(30, ErrorMessage = "username cannot be longer than 30 characters")]
        [MinLength(1, ErrorMessage = "you need more than 0 charaters for username")]
        public string username { get; set; }
        [Required]
        public string password { get; set; }
        public string first_name { get; set; }
        public string middle_name { get; set; }
        public string last_name { get; set; }
        public string EGN { get; set; }
        public string telephone { get; set; }
        public string email { get; set; }
        public string role { get; set; }
    }
}
