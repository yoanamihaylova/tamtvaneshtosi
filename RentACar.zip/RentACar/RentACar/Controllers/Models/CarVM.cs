﻿using RentACar.Database.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace RentACar.Controllers.Models
{
    public class CarVM
    {
        public List<Car> cars { get; set; }
        public int id { get; set; }

        [Required]
        public string brand { get; set; }
        public string model { get; set; }
        public int year { get; set; }
        public int places { get; set; }
        public string description { get; set; }
        public decimal price { get; set; }
        public string picture { get; set; }

    }
}
