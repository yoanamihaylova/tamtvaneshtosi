﻿using Microsoft.EntityFrameworkCore;
using RentACar.Database.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RentACar.Database
{
    public class RentACar : DbContext
    {
        public virtual DbSet<User> users { get; set; }
        public virtual DbSet<Rent> rents { get; set; }
        public virtual DbSet<Car> cars { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server = (localdb)\.; Database = rentacar;");
            optionsBuilder.UseLazyLoadingProxies();
        }
    
    }
}
