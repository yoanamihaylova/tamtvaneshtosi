﻿using RentACar.Controllers.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RentACar.Database.Models
{
    public class User
    {
        public int id { get; set; }
        public string username { get; set; }
        public string password { get; set; }
        public string first_name { get; set; }
        public string middle_name { get; set; }
        public string last_name { get; set; }
        public string EGN { get; set; }
        public string telephone { get; set; }
        public string email { get; set; }
        public string role { get; set; }
        public User()
        {

        }
        public User(UserVM other)
        {
            //   id = other.id;
            username = other.username;
            password = other.password;
            first_name = other.first_name;
            middle_name = other.middle_name;
            last_name = other.last_name;
            EGN = other.EGN;
            telephone = other.telephone;
            email = other.email;
            role = other.role;
        }
    }
}
