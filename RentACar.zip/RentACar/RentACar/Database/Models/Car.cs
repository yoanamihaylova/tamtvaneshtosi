﻿using RentACar.Controllers.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RentACar.Database.Models
{
    public class Car
    {

        public int id { get; set; }
        public string brand { get; set; }
        public string model { get; set; }
        public int year { get; set; }
        public int places { get; set; }
        public string description { get; set; }
        public decimal price { get; set; }
        public string picture { get; set; }
        public Car() 
        {
        }
        public Car(CarVM other)
        {
            //   id = other.id;
            brand = other.brand;
            model = other.model;
            year = other.year;
            places = other.places;
            description = other.description;
            price = other.price;
            picture = other.picture;
        }
    }
}
