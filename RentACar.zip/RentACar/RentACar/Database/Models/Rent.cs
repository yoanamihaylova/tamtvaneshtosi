﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RentACar.Database.Models
{
    public class Rent
    {
        public int id { get; set; }
        public DateTime startDate { get; set; }
        public DateTime endDate { get; set; }
        public virtual Car car { get; set; }
        public virtual User user { get; set; }
        public decimal finalPrice { get; set; }
        public string status { get; set; }
        public Rent()
        {

        }

    }
}
