﻿using RentACar.Database.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RentACar.Database
{
    public class DatabaseController
    {
        private RentACar context;
        public DatabaseController() { }
        public DatabaseController(RentACar context)
        {
            this.context = context;
        }
        public int addUser(User u)
        {
            context.users.Add(u);
            context.SaveChanges();
            return u.id;
        }       
        public int addRent(Rent u)
        {
            context.rents.Add(u);
            context.SaveChanges();
            return u.id;
        }       
        public int addCar(Car u)
        {
            context.cars.Add(u);
            context.SaveChanges();
            return u.id;
        }
        public List<User> getAllUsers()
        {
            return context.users.ToList();
        }
        public List<Car> getAllCars()
        {
            return context.cars.ToList();
        }
        public List<Rent> getAllRents()
        {
            return context.rents.ToList();
        }
        public void updateUser(User u)
        {
            User item = context.users.Find(u.id);
            context.Entry(item).CurrentValues.SetValues(u);

            context.SaveChanges();
        }
        public void updateCar(Car u)
        {
            Car item = context.cars.Find(u.id);
            context.Entry(item).CurrentValues.SetValues(u);

            context.SaveChanges();
        }
        public void updateRent(Rent u)
        {
            Rent item = context.rents.Find(u.id);
            context.Entry(item).CurrentValues.SetValues(u);

            context.SaveChanges();
        }
        public void deleteUser(int id)
        {
            context.users.Remove(context.users.Find(id));
            context.SaveChanges();
        }
        public void deleteRent(int id)
        {
            context.rents.Remove(context.rents.Find(id));
            context.SaveChanges();
        }
        public void deleteCar(int id)
        {
            context.cars.Remove(context.cars.Find(id));
            context.SaveChanges();
        }
    }
}
